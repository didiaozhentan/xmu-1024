/*   */
$.getJSON('js/map.json', function(data){
 	$.each(data, function (infoIndex, info){
     	var city = info.children;
 		for(var i =0;i<city.length;i++){
			var citydetail = new Array();
 			var name = city[i].name;
 			geoCoordMap[name]= citydetail;
 			var lat = parseFloat(city[i].lat);
 			var log = parseFloat(city[i].log);
 			citydetail.push(log);
 			citydetail.push(lat);
 		}
      }) 
     map_1_option.series[0].data = convertData(data2.sort(function (a, b) {
                return b.value - a.value;
            })),
/*            }).slice(0, 6)),
*/     map_1.setOption(map_1_option);
});


var geoCoordMap = {
	
};


var convertData = function (data) {
    var res = [];
    for (var i = 0; i < data.length; i++) {
        var geoCoord = geoCoordMap[data[i].name];
        if (geoCoord) {
            res.push({
                name: data[i].name,
                value: geoCoord.concat(data[i].value)
            });
        }
    }
    return res;
};
//地图容器
var map_1 = echarts.init(document.getElementById('map_1'));
//地图容器



//网络零售当期分布
var map_1_option = {

    geo: {
        map: 'china',
        label: {
            emphasis: {
                show: false
            }
        },
        roam: false,
        itemStyle: {
            normal: {
                areaColor: '#4c60ff',
                borderColor: '#000f4c',
            },
            emphasis: {
                areaColor: '#293fff'
            }
        }
    },

    series : [
    {
            name: 'pm2.5',
            type: 'scatter',
            coordinateSystem: 'geo',
            data: convertData(data2),
            symbolSize: function (val) {
                return val[2] / 20;
            },
            label: {
                normal: {
                    formatter: '{b}',
                    position: 'right',
                    show: false
                },
                emphasis: {
                    show: true
                }
            },
            itemStyle: {
                normal: {
                    color: '#ecf500'
                }
            }
        },
        {
            name: 'Top 5',
            type: 'effectScatter',
            coordinateSystem: 'geo',
            symbolSize: function (val) {
                return val[2] / 10;
            },
            showEffectOn: 'render',
            rippleEffect: {
                brushType: 'stroke'
            },
            hoverAnimation: true,
/*            label: {
                normal: {
                    formatter: '{b}',
                    position: 'right',
                    show: true,
                    color:'#333'
                },
                emphasis:{
                	color:'#333'
                }
            },*/
            itemStyle: {
                normal: {
                    color: '#f75749',
                    shadowBlur: 10,
                    shadowColor: '#333'
                }
            },
            zlevel: 1
        }
    ]
	
    };
$(document).ready(function(){
	　　map_1.resize();  
	
})
window.addEventListener("resize", function () {
　　map_1.resize();  
});
	
