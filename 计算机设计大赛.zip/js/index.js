$(function () {
    echart_1();


    echart_3();
    echart_4();

    echart_map();


    //echart_1gdp
    function echart_1() {
        // 基于准备好的dom，初始化echarts实例
        var myChart = echarts.init(document.getElementById('chart_1'));
        option = {
            tooltip: {
                trigger: 'item',
                formatter: "{a} {b} : {c}项",
            },
            legend: {
                x: 'center',
                y: '15%',
                data: [ '管理', '经济', '信息','航空', '电子', '化学','海洋','人文', '新闻'],
                icon: 'circle',
                textStyle: {
                    color: '#fff',
                }
            },
            calculable: true,
            series: [{
                name: '',
                type: 'pie',
                //起始角度，支持范围[0, 360]
                startAngle: 0,
                //饼图的半径，数组的第一项是内半径，第二项是外半径
                radius: [41, 100.75],
                //支持设置成百分比，设置成百分比时第一项是相对于容器宽度，第二项是相对于容器高度
                center: ['50%', '40%'],
                //是否展示成南丁格尔图，通过半径区分数据大小。可选择两种模式：
                // 'radius' 面积展现数据的百分比，半径展现数据的大小。
                //  'area' 所有扇区面积相同，仅通过半径展现数据大小
                roseType: 'area',
                //是否启用防止标签重叠策略，默认开启，圆环图这个例子中需要强制所有标签放在中心位置，可以将该值设为 false。
                avoidLabelOverlap: false,
                label: {
                    normal: {
                        show: true,
                        formatter: '{c}项'
                    },
                    emphasis: {
                        show: true
                    }
                },
                labelLine: {
                    normal: {
                        show: true,
                        length2: 1,
                    },
                    emphasis: {
                        show: true
                    }
                },
                data: [{
                        value: 9,
                        name: '新闻',
                        itemStyle: {
                            normal: {
                                color: '#f845f1'
                            }
                        }
                    },
                    {
                        value: 10,
                        name: '人文',
                        itemStyle: {
                            normal: {
                                color: '#ad46f3'
                            }
                        }
                    },
                    {
                        value: 13,
                        name: '海洋',
                        itemStyle: {
                            normal: {
                                color: '#5045f6'
                            }
                        }
                    },
                    {
                        value: 14,
                        name: '化学',
                        itemStyle: {
                            normal: {
                                color: '#4777f5'
                            }
                        }
                    },
                    {
                        value: 17,
                        name: '电子',
                        itemStyle: {
                            normal: {
                                color: '#44aff0'
                            }
                        }
                    },
                    {
                        value: 19,
                        name: '航空',
                        itemStyle: {
                            normal: {
                                color: '#45dbf7'
                            }
                        }
                    },
                    {
                        value: 20,
                        name: '信息',
                        itemStyle: {
                            normal: {
                                color: '#f6d54a'
                            }
                        }
                    },
                    {
                        value: 22,
                        name: '经济',
                        itemStyle: {
                            normal: {
                                color: '#f69846'
                            }
                        }
                    },
                    {
                        value: 22,
                        name: '管理',
                        itemStyle: {
                            normal: {
                                color: '#ff4343'
                            }
                        }
                    },
                    {
                        value: 0,
                        name: "",
                        itemStyle: {
                            normal: {
                                color: 'transparent'
                            }
                        },
                        label: {
                            show: false
                        },
                        labelLine: {
                            show: false
                        }
                    },
                    {
                        value: 0,
                        name: "",
                        itemStyle: {
                            normal: {
                                color: 'transparent'
                            }
                        },
                        label: {
                            show: false
                        },
                        labelLine: {
                            show: false
                        }
                    },
                    {
                        value: 0,
                        name: "",
                        itemStyle: {
                            normal: {
                                color: 'transparent'
                            }
                        },
                        label: {
                            show: false
                        },
                        labelLine: {
                            show: false
                        }
                    },
                    {
                        value: 0,
                        name: "",
                        itemStyle: {
                            normal: {
                                color: 'transparent'
                            }
                        },
                        label: {
                            show: false
                        },
                        labelLine: {
                            show: false
                        }
                    },
                    {
                        value: 0,
                        name: "",
                        itemStyle: {
                            normal: {
                                color: 'transparent'
                            }
                        },
                        label: {
                            show: false
                        },
                        labelLine: {
                            show: false
                        }
                    },
                    {
                        value: 0,
                        name: "",
                        itemStyle: {
                            normal: {
                                color: 'transparent'
                            }
                        },
                        label: {
                            show: false
                        },
                        labelLine: {
                            show: false
                        }
                    },
                    {
                        value: 0,
                        name: "",
                        itemStyle: {
                            normal: {
                                color: 'transparent'
                            }
                        },
                        label: {
                            show: false
                        },
                        labelLine: {
                            show: false
                        }
                    },
                    {
                        value: 0,
                        name: "",
                        itemStyle: {
                            normal: {
                                color: 'transparent'
                            }
                        },
                        label: {
                            show: false
                        },
                        labelLine: {
                            show: false
                        }
                    },
                    {
                        value: 0,
                        name: "",
                        itemStyle: {
                            normal: {
                                color: 'transparent'
                            }
                        },
                        label: {
                            show: false
                        },
                        labelLine: {
                            show: false
                        }
                    }
                ]
            }]
        };
        // 使用刚指定的配置项和数据显示图表。
        myChart.setOption(option);
        window.addEventListener("resize", function () {
            myChart.resize();
        });
    }

    // echart_map中国地图
    function echart_map() {
        // 基于准备好的dom，初始化echarts实例
        var myChart = echarts.init(document.getElementById('chart_map'));

        var mapName = 'china'
        var data = []
        var toolTipData = [];

        /*获取地图数据*/
        myChart.showLoading();
        var mapFeatures = echarts.getMap(mapName).geoJson.features;
        myChart.hideLoading();
        var geoCoordMap = {
            '福州': [119.4543, 25.9222],
            
            '重庆': [107.7539, 30.1904],
            '西安': [109.1162, 34.2004],
            '北京': [116.4551, 40.2539],
            '广州': [113.30, 23.12],
            '南宁': [108.29, 22.80],
            '贵阳': [106.70, 26.62],
            '南京': [118.77, 32.05],
            '西宁': [101.76,36.64],
            '济南': [117.02,36.68 ],
            '杭州': [120.21,30.25],
            '成都': [104.06,30.67 ],
            '上海': [121.48, 31.24],
            '昆明': [102.71,25.04 ],
            '天津': [117.21,39.14 ],
            '兰州': [103.82,36.06],
            '呼和浩特': [111.66,40.82]
        };

        var GZData = [
            [{
                name: '广州'
            }, {
                name: '贵阳',
                value: 95
            }],
            [{
                name: '南京'
            }, {
                name: '西安',
                value: 80
            }],
            [{
                name: '广州'
            }, {
                name: '南宁',
                value: 70
            }],
            [{
                name: '西安'
            }, {
                name: '南京',
                value: 60
            }],
            [{
                name: '南京'
            }, {
                name: '西宁',
                value: 50
            }],
            [{
                name: '济南'
            }, {
                name: '重庆',
                value: 40
            }],
            [{
                name: '重庆'
            }, {
                name: '济南',
                value: 30
            }],
            [{
                name: '杭州'
            }, {
                name: '成都',
                value: 20
            }],
            [{
                name: '成都'
            }, {
                name: '杭州',
                value: 10
            }],
            [{
                name: '上海'
            }, {
                name: '昆明',
                value: 80
            }],
            [{
                name: '昆明'
            }, {
                name: '上海',
                value: 80
            }],
            [{
                name: '福州'
            }, {
                name: '西宁',
                value: 80
            }],
            [{
                name: '西宁'
            }, {
                name: '福州',
                value: 80
            }],
            [{
                name: '天津'
            }, {
                name: '兰州',
                value: 80
            }],
            [{
                name: '兰州'
            }, {
                name: '天津',
                value: 80
            }],
            [{
                name: '南宁'
            }, {
                name: '广州',
                value: 80
            }],
            [{
                name: '北京'
            }, {
                name: '呼和浩特',
                value: 80
            }],
            [{
                name: '呼和浩特'
            }, {
                name: '北京',
                value: 80
            }],
            [{
                name: '贵阳'
            }, {
                name: '广州',
                value: 80
            }]


        ];

        var convertData = function (data) {
            var res = [];
            for (var i = 0; i < data.length; i++) {
                var dataItem = data[i];
                var fromCoord = geoCoordMap[dataItem[0].name];
                var toCoord = geoCoordMap[dataItem[1].name];
                if (fromCoord && toCoord) {
                    res.push({
                        fromName: dataItem[0].name,
                        toName: dataItem[1].name,
                        coords: [fromCoord, toCoord]
                    });
                }
            }
            return res;
        };

        var color = ['#c5f80e'];
        var series = [];
        [
            ['', GZData]
        ].forEach(function (item, i) {
            series.push({
                name: item[0],
                type: 'lines',
                zlevel: 2,
                symbol: ['none', 'arrow'],
                symbolSize: 10,
                effect: {
                    show: true,
                    period: 6,
                    trailLength: 0,
                    symbol: 'arrow',
                    symbolSize: 5
                },
                lineStyle: {
                    normal: {
                        color: color[i],
                        width: 1,
                        opacity: 0.6,
                        curveness: 0.2
                    }
                },
                data: convertData(item[1])
            }, {
                name: item[0],
                type: 'effectScatter',
                coordinateSystem: 'geo',
                zlevel: 2,
                rippleEffect: {
                    brushType: 'stroke'
                },
                label: {
                    normal: {
                        show: true,
                        position: 'right',
                        formatter: '{b}'
                    }
                },
                symbolSize: function (val) {
                    return val[2] / 8;
                },
                itemStyle: {
                    normal: {
                        color: color[i]
                    }
                },
                data: item[1].map(function (dataItem) {
                    return {
                        name: dataItem[1].name,
                        value: geoCoordMap[dataItem[1].name].concat([dataItem[1].value])
                    };
                })
            });
        });

        option = {
            tooltip: {
                trigger: 'item'
            },
            geo: {
                map: 'china',
                label: {
                    emphasis: {
                        show: false
                    }
                },
                roam: true,
                itemStyle: {
                    normal: {
                        borderColor: 'rgba(147, 235, 248, 1)',
                        borderWidth: 1,
                        areaColor: {
                            type: 'radial',
                            x: 0.5,
                            y: 0.5,
                            r: 0.8,
                            colorStops: [{
                                offset: 0,
                                color: 'rgba(175,238,238, 0)' // 0% 处的颜色
                            }, {
                                offset: 1,
                                color: 'rgba(47,79,79, .1)' // 100% 处的颜色
                            }],
                            globalCoord: false // 缺省为 false
                        },
                        shadowColor: 'rgba(128, 217, 248, 1)',
                        // shadowColor: 'rgba(255, 255, 255, 1)',
                        shadowOffsetX: -2,
                        shadowOffsetY: 2,
                        shadowBlur: 10
                    },
                    emphasis: {
                        areaColor: '#389BB7',
                        borderWidth: 0
                    }
                }
            },
            series: series
        };

        // 使用刚指定的配置项和数据显示图表。
        myChart.setOption(option);
        window.addEventListener("resize", function () {
            myChart.resize();
        });

    }

    //echart_3
    function echart_3() {
        // 基于准备好的dom，初始化echarts实例
        var myChart = echarts.init(document.getElementById('chart_3'));
        myChart.clear();
        option = {
            title: {
                text: ''
            },
            tooltip: {
                trigger: 'axis'
            },
            legend: {
                data:['人文科','理工科','经管科','艺术科'],
                textStyle:{
                    color: '#fff'
                },
                top: '8%'
            },
            grid: {
                top: '40%',
                left: '3%',
                right: '4%',
                bottom: '3%',
                containLabel: true
            },
            color: ['#FF4949','#FFA74D','#FFEA51','#4BF0FF','#44AFF0','#4E82FF','#584BFF','#BE4DFF','#F845F1'],
            xAxis: {
                type: 'category',
                boundaryGap: false,
                data: ['2018','2019','2020','2021','2022'],
                splitLine: {
                    show: false
                },
                axisLine: {
                    lineStyle: {
                        color: '#fff'
                    }
                }
            },
            yAxis: {
                name: '项',
                type: 'value',
                splitLine: {
                    show: false
                },
                axisLine: {
                    lineStyle: {
                        color: '#fff'
                    }
                }
            },
            series: [
                
                {
                    name:'人文科',
                    type:'line',
                    data:[80, 85, 97, 124, 134]
                },
                {
                    name:'理工科',
                    type:'line',
                    data:[114, 102, 152, 134, 182]
                },
                {
                    name:'经管科',
                    type:'line',
                    data:[98, 91, 88, 102, 120]
                },
                {
                    name:'艺术科',
                    type:'line',
                    data:[63,96,64,109,75]
                }
            ]
        };
        myChart.setOption(option);
    }
    //福建省地图
    function echart_4() {
          // 基于准备好的dom，初始化echarts实例
          var myChart = echarts.init(document.getElementById('chart_4'));

          myChart.setOption({
              series: [{
                  type: 'map',
                  mapType: 'hunan'
              }]
          });

          var geoCoordMap = {
              '厦门市': [118.13,24.59],
              '泉州市': [118.27,25.08],
              '福州市': [119.31,26.08],
              '莆田市': [119.01,25.36],
              '漳州市': [117.45,24.22],
              '宁德市': [119.61,26.93],
              '三明市': [117.44,26.27],
              '龙岩市': [116.73,25.27],
              '南平市': [118.05,27.29],
          };

          var goData = [
              [{
                  name: '三明市'

              }, {
                  id: 1,
                  name: '莆田市',
                  value: 86
              }],
              [{
                  name: '厦门市'

              }, {
                  id: 1,
                  name: '龙岩市',
                  value: 86
              }],
              [{
                  name: '莆田市'

              }, {
                  id: 1,
                  name: '漳州市',
                  value: 70
              }],
              [{
                  name: '漳州市'

              }, {
                  id: 1,
                  name: '龙岩市',
                  value: 95
              }],
              [{
                  name: '福州市'

              }, {
                  id: 1,
                  name: '宁德市',
                  value: 70
              }],
              [{
                  name: '福州市'

              }, {
                  id: 1,
                  name: '南平市',
                  value: 80
              }],
              [{
                  name: '福州市'

              }, {
                  id: 1,
                  name: '龙岩市',
                  value: 80
              }],
              [{
                  name: '福州市'

              }, {
                  id: 1,
                  name: '厦门市',
                  value: 80
              }],
              [{

                  name: '三明市'

              }, {
                  id: 1,
                  name: '龙岩市',
                  value: 70
              }],
              [{
                  name: '漳州市'

              }, {
                  id: 1,
                  name: '泉州市',
                  value: 70
              }],
              [{
                  name: '南平市'

              }, {
                  id: 1,
                  name: '龙岩市',
                  value: 60
              }],
              [{
                  name: '宁德市'

              }, {
                  id: 1,
                  name: '三明市',
                  value: 75
              }],
              [{
                  name: '泉州市'

              }, {
                  id: 1,
                  name: '厦门市',
                  value: 75
              }],
          ];
          //值控制圆点大小
          var backData = [
              [{
                  name: '莆田市'

              }, {
                  id: 1,
                  name: '三明市',
                  value: 80
              }],
              [{
                  name: '莆田市'

              }, {
                  id: 1,
                  name: '泉州市',
                  value: 66
              }],
              [{
                  name: '漳州市'

              }, {
                  id: 1,
                  name: '莆田市',
                  value: 86
              }],
              [{
                  name: '福州市'

              }, {
                  id: 1,
                  name: '漳州市',
                  value: 70
              }],
              [{
                  name: '宁德市'

              }, {
                  id: 1,
                  name: '福州市',
                  value: 95
              }],
              [{
                  name: '南平市'

              }, {
                  id: 1,
                  name: '福州市',
                  value: 95
              }],
              [{
                  name: '龙岩市'

              }, {
                  id: 1,
                  name: '福州市',
                  value: 95
              }],
              [{
                  name: '厦门市'

              }, {
                  id: 1,
                  name: '福州市',
                  value: 95
              }],
              [{
                  name: '莆田市'

              }, {
                  id: 1,
                  name: '三明市',
                  value: 80
              }],
              [{
                  name: '龙岩市'

              }, {
                  id: 1,
                  name: '泉州市',
                  value: 80
              }],
              [{
                  name: '莆田市'

              }, {
                  id: 1,
                  name: '南平市',
                  value: 80
              }],
              [{
                  name: '漳州市'

              }, {
                  id: 1,
                  name: '宁德市',
                  value: 60
              }],
              [{
                  name: '厦门市'

              }, {
                  id: 1,
                  name: '福州市',
                  value: 75
              }],
          ];

          var planePath = 'path://M1705.06,1318.313v-89.254l-319.9-221.799l0.073-208.063c0.521-84.662-26.629-121.796-63.961-121.491c-37.332-0.305-64.482,36.829-63.961,121.491l0.073,208.063l-319.9,221.799v89.254l330.343-157.288l12.238,241.308l-134.449,92.931l0.531,42.034l175.125-42.917l175.125,42.917l0.531-42.034l-134.449-92.931l12.238-241.308L1705.06,1318.313z';
          var arcAngle = function(data) {
              var j, k;
              for (var i = 0; i < data.length; i++) {
                  var dataItem = data[i];
                  if (dataItem[1].id == 1) {
                      j = 0;
                      return j;
                  } else if (dataItem[1].id == 2) {
                      k = 0;
                      return k;
                  }
              }
          }

          var convertData = function(data) {
              var res = [];
              for (var i = 0; i < data.length; i++) {
                  var dataItem = data[i];
                  var fromCoord = geoCoordMap[dataItem[0].name];
                  var toCoord = geoCoordMap[dataItem[1].name];
                  if (dataItem[1].id == 1) {
                      if (fromCoord && toCoord) {
                          res.push([{
                              coord: fromCoord,
                          }, {
                              coord: toCoord,
                              value: dataItem[1].value //线条颜色

                          }]);
                      }
                  } else if (dataItem[1].id == 2) {
                      if (fromCoord && toCoord) {
                          res.push([{
                              coord: fromCoord,
                          }, {
                              coord: toCoord
                          }]);
                      }
                  }
              }
              return res;
          };

          var color = ['#fff', '#FF1493', '#0000FF'];
          var series = [];
          [
              ['1', goData],
              ['2', backData]
          ].forEach(function(item, i) {
              series.push({
                  name: item[0],
                  type: 'lines',
                  zlevel: 2,
                  symbol: ['arrow', 'arrow'],
                  //线特效配置
                  effect: {
                      show: true,
                      period: 6,
                      trailLength: 0.1,
                      symbol: 'arrow', //标记类型
                      symbolSize: 5
                  },
                  lineStyle: {
                      normal: {
                          width: 1,
                          opacity: 0.4,
                          curveness: arcAngle(item[1]), //弧线角度
                          color: '#fff'
                      }
                  },
                  edgeLabel: {
                      normal: {
                          show: true,
                          textStyle: {
                              fontSize: 14
                          },
                          formatter: function(params) {
                              var txt = '';
                              if (params.data.speed !== undefined) {
                                  txt = params.data.speed;
                              }
                              return txt;
                          },
                      }
                  },
                  data: convertData(item[1])
              }, {
                  type: 'effectScatter',
                  coordinateSystem: 'geo',
                  zlevel: 2,
                  //波纹效果
                  rippleEffect: {
                      period: 2,
                      brushType: 'stroke',
                      scale: 3
                  },
                  label: {
                      normal: {
                          show: true,
                          color: '#fff',
                          position: 'right',
                          formatter: '{b}'
                      }
                  },
                  //终点形象
                  symbol: 'circle',
                  //圆点大小
                  symbolSize: function(val) {
                      return val[2] / 8;
                  },
                  itemStyle: {
                      normal: {
                          show: true
                      }
                  },
                  data: item[1].map(function(dataItem) {
                      return {
                          name: dataItem[1].name,
                          value: geoCoordMap[dataItem[1].name].concat([dataItem[1].value])
                      };
                  })

              });

          });

          option = {
              title: {
                  text: '',
                  subtext: '',
                  left: 'center',
                  textStyle: {
                      color: '#fff'
                  }
              },
              tooltip: {
                  trigger: 'item',
                  formatter: '{b}'
              },
              //线颜色及飞行轨道颜色
              visualMap: {
                  show: false,
                  min: 0,
                  max: 100,
                  color: ['#31A031','#31A031']
              },
              //地图相关设置
              geo: {
                  map: 'hunan',
                  //视角缩放比例
                  zoom: 1,
                  //显示文本样式
                  label: {
                      normal: {
                          show: false,
                          textStyle: {
                              color: '#fff'
                          }
                      },
                      emphasis: {
                          textStyle: {
                              color: '#fff'
                          }
                      }
                  },
                  //鼠标缩放和平移
                  roam: true,
                  itemStyle: {
                      normal: {
                          //          	color: '#ddd',
                          borderColor: 'rgba(147, 235, 248, 1)',
                          borderWidth: 1,
                          areaColor: {
                              type: 'radial',
                              x: 0.5,
                              y: 0.5,
                              r: 0.8,
                              colorStops: [{
                                  offset: 0,
                                  color: 'rgba(175,238,238, 0)' // 0% 处的颜色
                              }, {
                                  offset: 1,
                                  color: 'rgba(	47,79,79, .2)' // 100% 处的颜色
                              }],
                              globalCoord: false // 缺省为 false
                          },
                          shadowColor: 'rgba(128, 217, 248, 1)',
                          // shadowColor: 'rgba(255, 255, 255, 1)',
                          shadowOffsetX: -2,
                          shadowOffsetY: 2,
                          shadowBlur: 10
                      },
                      emphasis: {
                          areaColor: '#389BB7',
                          borderWidth: 0
                      }
                  }
              },
              series: series
          };
          myChart.setOption(option);

    }
    
});
