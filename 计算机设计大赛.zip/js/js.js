﻿ $(window).load(function(){$(".loading").fadeOut()})  
$(function () {
    echarts_9();
function echarts_1() {
        // 基于准备好的dom，初始化echarts实例
        
option = {

    color: ['#9DD060', '#35C96E', '#4DCEF8'],

    tooltip: {},
  
    radar: {
        center: ['50%', '50%'],
	 radius: ["25%", "70%"],
		
        name: {
            textStyle: {
                color: '#72ACD1'
            }
        },

          splitLine: {

              lineStyle: {

                  color: 'rgba(255,255,255,.0',

                  width: 2

              }

          },
          axisLine: {
              lineStyle: {
                  color: 'rgba(255,255,255,0.2)',
                  width: 1,
                  type: 'dotted'

              },

          },
        splitArea: {
            areaStyle: {
                  color: []
              }
        },
        indicator: data[2]
    },
    series: [{
        name: '',
        type: 'radar',
        data: [{
                areaStyle: {
                    normal: {
                        opacity: 0.3,
                    }
                },
                value: data[3],
                name: data[1][0]
            },
            {
                areaStyle: {
                    normal: {
                        opacity: 0.3,
                    }
                },
                value: data[4],
                name: data[1][1]
            },
            {
                areaStyle: {
                    normal: {
                        opacity: 0.3,
                    }
                },
                value: data[5],
                name: data[1][2]
            }
        ]
    }]
};
        // 使用刚指定的配置项和数据显示图表。
        myChart.setOption(option);
        window.addEventListener("resize",function(){
            myChart.resize();
        });
    }
    function echarts_9() {
        var myChart = echarts.init(document.getElementById('echart9'));
        option = {
            tooltip: {
            trigger: 'axis',
            axisPointer: {type: 'shadow'},
        },

        grid: {
            left: '25',
              top: '40',
            right: '0',
            bottom: '0',
            containLabel: true
        },
        xAxis: {
            type: 'category',
            data: ['2017年', '2018年', '2019年', '2020年', '2021年'],
            axisLine: {show:false},
           
            axisLabel: {
              textStyle: {
               color:'rgba(255,255,255,.5)',
    
              }
            },
          },
  
          yAxis: {
            type: 'value',
            splitNumber:4,
            axisLine: { show: false },
         axisTick: {show: false},
            splitLine: {
              show: true,
              lineStyle: {
                color: 'rgba(255,255,255,0.05)'
              }
            },
            axisLabel:  {
                textStyle: {
                     color: "rgba(255,255,255,.5)",
                           },
                       },
          },
        series: [ {
            name: '全国人均GDP',
            type: 'bar',
            barWidth: '25%',
            itemStyle: {
                normal: {
                    color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                        offset: 0,
                        color: '#8bd46e'
                    }, {
                        offset: 1,
                        color: '#03b48e'
                    }]),
                    barBorderRadius: 11,
                }
                
              },
            data: [59200,64643,70892,72447,80976]
        
        },
            {
            name: '福建人均GDP',
            type: 'bar',
          barWidth: '25%',
          itemStyle: {
            normal: {
                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                    offset: 0,
                    color: '#3893e5'
                }, {
                    offset: 1,
                    color: '#248ff7'
                }]),
            barBorderRadius: 11,
            }
          },
            data: [83758,94719, 102722, 105818,116939]
        
        }
    
    ]
        };
               myChart.setOption(option);
               window.addEventListener("resize",function(){
                   myChart.resize();
               });
           }





    function echarts_15() {
        var myChart = echarts.init(document.getElementById('map'));
        		

var convertData = function (data) {
   var res = [];
   for (var i = 0; i < data.length; i++) {
       var geoCoord = geoCoordMap[data[i].name];
       if (geoCoord) {
           res.push({
               name: data[i].name,
               value: geoCoord.concat(data[i].value)
           });
       }
   }
   return res;
};

option = {

   tooltip : {
       trigger: 'item'
   },
 
   geo: {

       map: 'china',
       zoom: 1.1,//放大
       label: {
           emphasis: {
               show: false
           }
       },
       roam: true,
       itemStyle: {
        normal: {
            areaColor: 'rgba(2,37,101,.5)',
            borderColor: 'rgba(112,187,252,.5)'
        },
        emphasis: {
            areaColor: 'rgba(2,37,101,.8)'
        }
    }
   },

};
           }
})



		
		
		


		









